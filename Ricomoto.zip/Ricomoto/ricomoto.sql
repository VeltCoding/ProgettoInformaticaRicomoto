-- Ricomoto multitenant schema
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
/*!40101 SET NAMES utf8mb4 */;

DROP TABLE IF EXISTS `notifica`;
DROP TABLE IF EXISTS `prodotto`;
DROP TABLE IF EXISTS `shop`;
DROP TABLE IF EXISTS `refresh_token`;
DROP TABLE IF EXISTS `admin`;
DROP TABLE IF EXISTS `user_permissions`;
DROP TABLE IF EXISTS `role_permissions`;
DROP TABLE IF EXISTS `user_roles`;
DROP TABLE IF EXISTS `permissions`;
DROP TABLE IF EXISTS `roles`;
DROP TABLE IF EXISTS `officina`;
DROP TABLE IF EXISTS `utente`;

CREATE TABLE `utente` (
  `ID` int(30) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `email` varchar(80) NOT NULL,
  `indirizzo` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `uq_utente_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `officina` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `iva` varchar(20) NOT NULL,
  `indirizzo` varchar(80) NOT NULL,
  `utente_id` int(11) NOT NULL,
  `cellulare` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_officina_utente` (`utente_id`),
  UNIQUE KEY `uq_officina_iva` (`iva`),
  CONSTRAINT `fk_officina_utente` FOREIGN KEY (`utente_id`) REFERENCES `utente` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `officina_id` int(30) NOT NULL,
  `nome` varchar(120) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `localita` varchar(120) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `descrizione` text DEFAULT NULL,
  `status` enum('active','suspended') NOT NULL DEFAULT 'active',
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_shop_officina` (`officina_id`),
  UNIQUE KEY `uq_shop_slug` (`slug`),
  CONSTRAINT `fk_shop_officina` FOREIGN KEY (`officina_id`) REFERENCES `officina` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `utente_id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `numero` varchar(15) NOT NULL,
  `email` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `utente_id` (`utente_id`),
  CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`utente_id`) REFERENCES `utente` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `user_permissions` (
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `utente` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `user_roles` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `utente` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `prodotto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `officina_id` int(11) NOT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `titolo` varchar(150) NOT NULL,
  `descrizione` text NOT NULL,
  `immagine` varchar(255) NOT NULL,
  `stato` enum('disponibile','venduto') NOT NULL DEFAULT 'disponibile',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `officina_id` (`officina_id`),
  KEY `shop_id` (`shop_id`),
  CONSTRAINT `fk_prodotto_officina` FOREIGN KEY (`officina_id`) REFERENCES `officina` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_prodotto_shop` FOREIGN KEY (`shop_id`) REFERENCES `shop` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `notifica` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `officina_id` int(11) NOT NULL,
  `prodotto_id` int(11) NOT NULL,
  `utente_id` int(11) NOT NULL,
  `messaggio` varchar(255) NOT NULL,
  `letto` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `officina_id` (`officina_id`),
  KEY `prodotto_id` (`prodotto_id`),
  KEY `utente_id` (`utente_id`),
  CONSTRAINT `fk_notifica_officina` FOREIGN KEY (`officina_id`) REFERENCES `officina` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_notifica_prodotto` FOREIGN KEY (`prodotto_id`) REFERENCES `prodotto` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_notifica_utente` FOREIGN KEY (`utente_id`) REFERENCES `utente` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `refresh_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `token_hash` (`token_hash`),
  CONSTRAINT `fk_refresh_user` FOREIGN KEY (`user_id`) REFERENCES `utente` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Amministratore del sito'),
(2, 'cliente', 'Cliente: compra prodotti'),
(3, 'officina', 'Officina: gestisce shop e catalogo');

INSERT INTO `permissions` (`id`, `code`, `description`) VALUES
(1, 'catalogo.leggi', 'Vedere e cercare prodotti'),
(2, 'carrello.gestisci', 'Gestire carrello'),
(3, 'ordine.crea', 'Acquistare prodotti'),
(4, 'ordine.leggi', 'Vedere i propri ordini'),
(5, 'recensione.crea', 'Scrivere recensione'),
(6, 'offerta.crea', 'Fare offerta di prezzo'),
(7, 'prodotto.crea', 'Caricare prodotto'),
(8, 'prodotto.aggiorna', 'Modificare prodotto (proprio)'),
(9, 'prodotto.leggi_miei', 'Vedere i propri prodotti'),
(10, 'offerta.gestisci', 'Accettare/rifiutare offerte ricevute'),
(11, 'recensione.rispondi', 'Rispondere alle recensioni'),
(12, 'utenti.gestisci', 'Gestire utenti e tenant'),
(13, 'prodotto.disattiva', 'Disattivare prodotto'),
(14, 'prodotto.elimina', 'Eliminare prodotto'),
(15, 'prodotto.leggi', 'Leggere tutti i prodotti'),
(16, 'acquisto.crea', 'Acquistare prodotto'),
(17, 'notifica.leggi', 'Leggere notifiche');

INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),
(2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(2,15),(2,16),
(3,1),(3,7),(3,8),(3,9),(3,10),(3,11),(3,15),(3,17);

INSERT INTO `utente` (`ID`, `nome`, `cognome`, `telefono`, `email`, `indirizzo`, `password`) VALUES
(1, 'Admin', 'Ricomoto', '0000000000', 'admin@ricomoto.local', 'Ricomoto HQ', '$2y$12$K6Yh6Y0f8kNvh73FFXlT8uuldd5eb2OCE7bAa0yrXHrW/IQcCo5ge');

INSERT INTO `admin` (`id`, `utente_id`, `nome`, `cognome`, `numero`, `email`) VALUES
(1, 1, 'Admin', 'Ricomoto', '0000000000', 'admin@ricomoto.local');

INSERT INTO `user_roles` (`user_id`, `role_id`) VALUES
(1, 1);

COMMIT;
