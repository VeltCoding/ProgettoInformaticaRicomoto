<?php
require_once __DIR__ . '/auth.php';
requirePermission('prodotto.leggi');
$msg = $_GET['msg'] ?? null;
$sql = "SELECT p.*, o.nome AS nome_officina, s.nome AS nome_shop, s.slug AS shop_slug
        FROM prodotto p
        JOIN officina o ON o.id = p.officina_id
        LEFT JOIN shop s ON s.id = p.shop_id
        ORDER BY p.created_at DESC";
$prodotti = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);
$canBuy = hasPermission('acquisto.crea');
$shop = currentShop();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Marketplace - Ricomoto</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="page-shell">
  <div class="container wide-container">
    <div class="brandbar">
      <a class="brand compact" href="<?= htmlspecialchars(appUrl('index.php')) ?>"><img src="<?= htmlspecialchars(assetUrl('assets/ricomoto-logo.svg')) ?>" alt="Ricomoto"></a>
      <div class="btn-row">
        <a class="btn btn-ghost" href="<?= htmlspecialchars(dashboardTarget()) ?>">Dashboard</a>
        <?php if ($shop): ?><a class="btn btn-primary" href="<?= htmlspecialchars(appUrl('gestisci_shop.php')) ?>">Il mio shop</a><?php endif; ?>
      </div>
    </div>

    <section class="card">
      <div class="section-head">
        <div>
          <div class="kicker">Marketplace</div>
          <h2>Catalogo globale Ricomoto</h2>
          <p>Vista cross-tenant di tutti i prodotti pubblicati dagli shop e dalle officine.</p>
        </div>
      </div>
      <?php if ($msg): ?><div class="ok"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
    </section>

    <section class="section grid-products">
      <?php foreach ($prodotti as $p): ?>
        <article class="product-card">
          <div class="product-img"><img src="<?= htmlspecialchars(mediaUrl($p['immagine'])) ?>" alt="img"></div>
          <div class="product-body">
            <div class="product-title"><?= htmlspecialchars($p['titolo']) ?></div>
            <div class="product-sub">Officina: <?= htmlspecialchars($p['nome_officina']) ?></div>
            <?php if (!empty($p['nome_shop'])): ?>
              <div class="small">Shop: <a class="link" target="_blank" href="<?= htmlspecialchars(tenantStoreUrl($p['shop_slug'])) ?>"><?= htmlspecialchars($p['nome_shop']) ?></a></div>
            <?php endif; ?>
            <div class="product-desc"><?= nl2br(htmlspecialchars($p['descrizione'])) ?></div>
            <div class="product-footer">
              <span class="product-status <?= $p['stato'] === 'venduto' ? 'sold' : 'avail' ?>"><?= htmlspecialchars($p['stato']) ?></span>
            </div>
            <?php if ($canBuy && $p['stato'] === 'disponibile'): ?>
              <form method="POST" action="<?= htmlspecialchars(appUrl('acquista.php')) ?>" class="mt-16">
                <input type="hidden" name="prodotto_id" value="<?= (int)$p['id'] ?>">
                <button class="btn btn-primary" type="submit">Acquista</button>
              </form>
              <form method="POST" action="<?= htmlspecialchars(appUrl('notifica.php')) ?>" class="mt-12">
                <input type="hidden" name="prodotto_id" value="<?= (int)$p['id'] ?>">
                <textarea name="messaggio" rows="2" placeholder="Scrivi una richiesta per l'officina..." required></textarea>
                <button class="btn btn-ghost mt-12" type="submit">Chiedi info</button>
              </form>
            <?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
    </section>
  </div>
</div>
</body>
</html>
