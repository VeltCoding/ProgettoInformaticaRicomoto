<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/api/jwt.php';
if (currentTenantShop()) {
    header('Location: ' . appUrl('shop.php'));
    exit;
}
$err = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $login = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';
  if ($login === '' || $password === '') {
    $err = 'Compila email e password.';
  } else {
    $stmt = $conn->prepare('SELECT ID, password FROM utente WHERE email = ? OR nome = ? LIMIT 1');
    $stmt->bind_param('ss', $login, $login);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($user && password_verify($password, $user['password'])) {
      $uid = (int)$user['ID'];
      $_SESSION['user_id'] = $uid;
      $_SESSION['roles'] = loadUserRoles($uid);
      $_SESSION['permissions'] = loadPermissions($uid);
      $_SESSION['jwt'] = jwt_sign(['sub' => $uid], 600);
      $_SESSION['jwt_exp'] = time() + 600;
      header('Location: ' . dashboardTarget());
      exit;
    } else {
      $err = 'Credenziali errate.';
    }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Login - Ricomoto</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="auth-wrap">
    <div class="container narrow-container auth-layout">
      <section class="auth-showcase">
        <a class="brand compact" href="<?= htmlspecialchars(appUrl('index.php')) ?>"><img src="<?= htmlspecialchars(assetUrl('assets/ricomoto-logo.svg')) ?>" alt="Ricomoto"></a>
        <div class="eyebrow mt-20">Bentornato</div>
        <h2>Accedi al tuo spazio Ricomoto.</h2>
   
      </section>
      <section class="auth-panel">
        <div class="kicker">Login</div>
        <h2>Accedi al pannello</h2>
        <p>Inserisci le tue credenziali per continuare.</p>
        <?php if ($err): ?><div class="alert"><?= htmlspecialchars($err) ?></div><?php endif; ?>
        <form method="POST">
          <div class="field"><label>Email o username</label><input name="email" type="text" required></div>
          <div class="field"><label>Password</label><input name="password" type="password" required></div>
          <div class="btn-row mt-16">
            <button class="btn btn-primary" type="submit">Entra</button>
            <a class="btn btn-ghost" href="<?= htmlspecialchars(appUrl('register.php')) ?>">Registrati</a>
          </div>
          <div class="small mt-16">Torna alla <a class="link" href="<?= htmlspecialchars(appUrl('index.php')) ?>">home</a></div>
        </form>
      </section>
    </div>
  </div>
</body>
</html>
