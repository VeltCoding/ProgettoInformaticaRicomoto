<?php
require_once __DIR__ . '/auth.php';
$shop = ensureTenantContextOrRedirect();
if ($shop['status'] !== 'active' && !hasRole('admin')) {
    http_response_code(403);
    die('Questo tenant è sospeso.');
}
$stmt = $conn->prepare('SELECT * FROM prodotto WHERE shop_id = ? ORDER BY created_at DESC');
$shopId = (int)$shop['id'];
$stmt->bind_param('i', $shopId);
$stmt->execute();
$prodotti = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$canBuy = isLoggedIn() && hasPermission('acquisto.crea');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title><?= htmlspecialchars($shop['nome']) ?> - Ricomoto</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="page-shell">
  <div class="container wide-container">
    <div class="brandbar">
      <a class="brand compact" href="<?= htmlspecialchars(appUrl('index.php')) ?>"><img src="<?= htmlspecialchars(assetUrl('assets/ricomoto-logo.svg')) ?>" alt="Ricomoto"></a>
      <div class="btn-row">
        <?php if (isLoggedIn()): ?><a class="btn btn-ghost" href="<?= htmlspecialchars(dashboardTarget()) ?>">Dashboard</a><?php else: ?><a class="btn btn-ghost" href="<?= htmlspecialchars(appUrl('login.php')) ?>">Login</a><?php endif; ?>
        <a class="btn btn-primary" href="<?= htmlspecialchars(appUrl('prodotti.php')) ?>">Marketplace</a>
      </div>
    </div>

    <section class="card">
      <div class="shop-hero">
        <div class="shop-logo-box large"><?= !empty($shop['logo']) ? '<img class="shop-logo" src="'.htmlspecialchars(mediaUrl($shop['logo'])).'" alt="logo">' : '<div class="shop-logo-fallback">'.htmlspecialchars(strtoupper(substr($shop['nome'],0,1))).'</div>' ?></div>
        <div class="shop-hero-copy">
          <div class="eyebrow">Tenant shop</div>
          <h1 style="font-size:clamp(2rem,4vw,3.2rem);margin-top:14px;"><?= htmlspecialchars($shop['nome']) ?></h1>
          <p><?= htmlspecialchars($shop['localita']) ?></p>
          <div class="small"><?= nl2br(htmlspecialchars($shop['descrizione'] ?: 'Shop Ricomoto dedicato ai ricambi e accessori moto.')) ?></div>
          <div class="badge-row mt-16">
            <span class="badge"><?= count($prodotti) ?> prodotti pubblicati</span>
            <span class="badge">Status: <?= htmlspecialchars($shop['status']) ?></span>
          </div>
        </div>
        <div class="panel" style="padding:20px;border-radius:26px;min-width:240px;">
          <div class="small">Storefront ufficiale</div>
          <div class="headline-sm mt-12"><?= htmlspecialchars($shop['slug']) ?>.ricomoto</div>
          <p class="mt-12">Sfoglia il catalogo dedicato a questo tenant.</p>
        </div>
      </div>
    </section>

    <section class="section grid-products">
      <?php foreach ($prodotti as $p): ?>
        <article class="product-card">
          <div class="product-img"><img src="<?= htmlspecialchars(mediaUrl($p['immagine'])) ?>" alt="img"></div>
          <div class="product-body">
            <div class="product-title"><?= htmlspecialchars($p['titolo']) ?></div>
            <div class="product-desc"><?= nl2br(htmlspecialchars($p['descrizione'])) ?></div>
            <div class="product-footer">
              <span class="product-status <?= $p['stato'] === 'venduto' ? 'sold' : 'avail' ?>"><?= htmlspecialchars($p['stato']) ?></span>
            </div>
            <?php if ($canBuy && $p['stato'] === 'disponibile'): ?>
              <form method="POST" action="<?= htmlspecialchars(appUrl('acquista.php')) ?>" class="mt-16">
                <input type="hidden" name="prodotto_id" value="<?= (int)$p['id'] ?>">
                <button class="btn btn-primary" type="submit">Acquista</button>
              </form>
              <form method="POST" action="<?= htmlspecialchars(appUrl('notifica.php')) ?>" class="mt-12">
                <input type="hidden" name="prodotto_id" value="<?= (int)$p['id'] ?>">
                <textarea name="messaggio" rows="2" placeholder="Scrivi la tua richiesta per lo shop..." required></textarea>
                <button class="btn btn-ghost mt-12" type="submit">Chiedi info</button>
              </form>
            <?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
    </section>
  </div>
</div>
</body>
</html>
