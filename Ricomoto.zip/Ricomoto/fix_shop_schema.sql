-- Usa questo file solo se hai gia' importato una versione rotta del progetto.
-- Se puoi, il modo piu' pulito resta: elimina il DB ricomoto e reimporta ricomoto.sql.

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS shop;

CREATE TABLE `shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `officina_id` int(30) NOT NULL,
  `nome` varchar(120) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `localita` varchar(120) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `descrizione` text DEFAULT NULL,
  `status` enum('active','suspended') NOT NULL DEFAULT 'active',
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_shop_officina` (`officina_id`),
  UNIQUE KEY `uq_shop_slug` (`slug`),
  CONSTRAINT `fk_shop_officina` FOREIGN KEY (`officina_id`) REFERENCES `officina` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE prodotto
  DROP FOREIGN KEY fk_prodotto_shop;

ALTER TABLE prodotto
  ADD CONSTRAINT `fk_prodotto_shop` FOREIGN KEY (`shop_id`) REFERENCES `shop` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

SET FOREIGN_KEY_CHECKS=1;
