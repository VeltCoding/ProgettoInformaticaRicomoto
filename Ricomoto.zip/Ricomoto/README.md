# Ricomoto Multitenant

Marketplace per ricambi/accessori moto con tre profili:
- cliente: compra e chiede info
- officina: crea uno shop tenant e gestisce il proprio catalogo
- admin: accede alla SuperDashboard e gestisce tutti i tenant

## Novità introdotte
- multitenancy con tabella `shop`
- `superdashboard.php` per admin
- `crea_shop.php` per creare il tenant shop
- `gestisci_shop.php` per gestire shop e prodotti
- `shop.php` come storefront tenant-aware
- routing tenant tramite host (`slug.localhost`) con fallback via `?tenant=slug`
- catalogo globale con link ai tenant

## Credenziali admin seed
- email: `admin@ricomoto.local`
- password: `admin123`

## Tenant locale
L'app legge automaticamente il tenant dallo host, per esempio:
- `http://ilyasmoto.localhost/ricomoto/ricomoto/shop.php`

Se stai entrando dal dominio centrale, resta disponibile anche il fallback:
- `http://localhost/ricomoto/ricomoto/shop.php?tenant=ilyasmoto`
