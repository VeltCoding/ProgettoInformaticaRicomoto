SET FOREIGN_KEY_CHECKS = 0;

DELETE FROM notifica;
DELETE FROM prodotto;
DELETE FROM shop;
DELETE FROM officina;
DELETE FROM admin;
DELETE FROM refresh_token;
DELETE FROM user_permissions;
DELETE FROM user_roles;
DELETE FROM utente;

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO utente (ID, nome, cognome, telefono, email, indirizzo, password)
VALUES (1, 'Admin', 'Ricomoto', '0000000000', 'admin@ricomoto.local', 'Ricomoto HQ', '$2y$12$K6Yh6Y0f8kNvh73FFXlT8uuldd5eb2OCE7bAa0yrXHrW/IQcCo5ge');

INSERT INTO admin (id, utente_id, nome, cognome, numero, email)
VALUES (1, 1, 'Admin', 'Ricomoto', '0000000000', 'admin@ricomoto.local');

INSERT INTO user_roles (user_id, role_id)
VALUES (1, 1);
